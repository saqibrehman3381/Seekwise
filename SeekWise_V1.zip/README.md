
# SeekWise AI

Explore divine knowledge from Quran to Science using AI.  
This is version 1 of the web-based auto-research platform.
